using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoatScript : MonoBehaviour
{
    public GameController GC;

    public void Start()
    {

    }
    public void Update()
    {

    }
}
