using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TileScript : MonoBehaviour
{
    [SerializeField] private Color baseColor, offsetColor;
    [SerializeField] private SpriteRenderer tileColor;
    [SerializeField] private GameObject highlight;

    public bool thisTarget;
    public GameController GC;

    public void Start()
    {
        GC = GameObject.Find("GameController").GetComponent<GameController>();
    }

    public void Init(bool isOffset)
    {
        tileColor.color = isOffset ? offsetColor : baseColor;
    }

    public void OnMouseEnter()
    {
        highlight.SetActive(true);
    }
    public void OnMouseExit()
    {
        highlight.SetActive(false);
    }
    public void OnMouseDown()
    {
        GC.TargetFound(this.transform.position.x, this.transform.position.y);
    }
}
