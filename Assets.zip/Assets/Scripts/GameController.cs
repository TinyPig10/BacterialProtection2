using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{

    public float[,] grid;

    public Vector2Int targetCell;
    public Vector2Int startCell;
    public Vector2Int currentCell;
    public Vector2Int comparingCell;
    public Vector2Int moveTo;
    public List<Vector2Int> compareList;
    public float addNum;


    public void Start()
    {
        grid = new float[12, 9];
    }
    public void TargetFound(float x, float y)
    {
        //-2 means a square that cannot be moved to, -1 means a square that has not been considered yet, 0 is the target square and positive numbers are how many squares away a node is
        targetCell.x = (int) x;
        targetCell.y = (int) y;
        if (grid[targetCell.x, targetCell.y] != -2)
        {
            for(var i = 0; i < 11; i++)
            {
                for(var j = 0; j < 8; j++)
                {
                    if(grid[i, j] != -2)
                    {
                        grid[i, j] = -1;
                    }
                }
            }
            compareList.Add(targetCell);
            grid[currentCell.x, currentCell.y] = 0;
            while (grid[startCell.x, startCell.y] == -1)
            {
                //everything above this is okay
                currentCell = compareList[0];
                addNum = grid[compareList[0].x, compareList[0].y] + 1;
                if (currentCell.y < 8)
                {
                    comparingCell = new Vector2Int(currentCell.x + 1, currentCell.y);
                    if((grid[comparingCell.x, comparingCell.y] != -2) && ((addNum < grid[comparingCell.x, comparingCell.y]) || grid[comparingCell.x, comparingCell.y] == -1))
                    {
                        addNum = grid[currentCell.x, currentCell.y] + 1;
                        grid[comparingCell.x, comparingCell.y] = addNum;
                        compareList.Add(comparingCell);
                    }
                }
                if (currentCell.x < 11)
                {
                    comparingCell = new Vector2Int(currentCell.x, currentCell.y + 1);
                    if ((grid[comparingCell.x, comparingCell.y] != -2) && ((addNum < grid[comparingCell.x, comparingCell.y]) || grid[comparingCell.x, comparingCell.y] == -1))
                    {
                        addNum = grid[currentCell.x, currentCell.y] + 1;
                        grid[comparingCell.x, comparingCell.y] = addNum;
                        compareList.Add(comparingCell);
                    }
                }
                if (currentCell.x > 0)
                {
                    comparingCell = new Vector2Int(currentCell.x - 1, currentCell.y);
                    if ((grid[comparingCell.x, comparingCell.y] != -2) && ((addNum < grid[comparingCell.x, comparingCell.y]) || grid[comparingCell.x, comparingCell.y] == -1))
                    {
                        addNum = grid[currentCell.x, currentCell.y] + 1;
                        grid[comparingCell.x, comparingCell.y] = addNum;
                        compareList.Add(comparingCell);
                    }
                }
                if(currentCell.y > 0)
                {
                    comparingCell = new Vector2Int(currentCell.x, currentCell.y - 1);
                    if ((grid[comparingCell.x, comparingCell.y] != -2) && ((addNum < grid[comparingCell.x, comparingCell.y]) || grid[comparingCell.x, comparingCell.y] == -1))
                    {
                        addNum = grid[currentCell.x, currentCell.y] + 1;
                        grid[comparingCell.x, comparingCell.y] = addNum;
                        compareList.Add(comparingCell);
                    }
                }
                compareList.Remove(currentCell);
            }
            moveTo = new Vector2Int(startCell.x, startCell.y + 1);
            if(grid[startCell.x + 1, startCell.y] > grid[moveTo.x, moveTo.y])
            {
                moveTo = new Vector2Int(startCell.x + 1, startCell.y);
            }
            if(grid[startCell.x, startCell.y - 1] > grid[moveTo.x, moveTo.y])
            {
                moveTo = new Vector2Int(startCell.x, startCell.y - 1);
            }
            if(grid[startCell.x - 1, startCell.y] > grid[moveTo.x, moveTo.y])
            {
                moveTo = new Vector2Int(startCell.x - 1, startCell.y);
            }
        }
    }
}
